# -*- coding: utf-8 -*-
"""Runtime Protobuf classes for proto/telemetry.proto.

This checked-in module keeps the prototype runnable on machines that do not
have the protoc compiler installed. The message classes are built with the
official google.protobuf runtime and preserve normal SerializeToString /
ParseFromString behavior.
"""
from __future__ import annotations

from google.protobuf import descriptor_pb2, descriptor_pool, message_factory


def _build_file_descriptor() -> descriptor_pb2.FileDescriptorProto:
    file_proto = descriptor_pb2.FileDescriptorProto()
    file_proto.name = "proto/telemetry.proto"
    file_proto.package = "telemetry"
    file_proto.syntax = "proto3"

    reading = file_proto.message_type.add()
    reading.name = "Reading"
    for number, name, field_type in (
        (1, "sensor_id", descriptor_pb2.FieldDescriptorProto.TYPE_STRING),
        (2, "type", descriptor_pb2.FieldDescriptorProto.TYPE_STRING),
        (3, "value", descriptor_pb2.FieldDescriptorProto.TYPE_DOUBLE),
        (4, "timestamp", descriptor_pb2.FieldDescriptorProto.TYPE_DOUBLE),
        (5, "unit", descriptor_pb2.FieldDescriptorProto.TYPE_STRING),
        (6, "location", descriptor_pb2.FieldDescriptorProto.TYPE_STRING),
    ):
        field = reading.field.add()
        field.name = name
        field.number = number
        field.label = descriptor_pb2.FieldDescriptorProto.LABEL_OPTIONAL
        field.type = field_type

    registration = file_proto.message_type.add()
    registration.name = "SensorRegistration"
    for number, name in ((1, "id"), (2, "type"), (3, "location")):
        field = registration.field.add()
        field.name = name
        field.number = number
        field.label = descriptor_pb2.FieldDescriptorProto.LABEL_OPTIONAL
        field.type = descriptor_pb2.FieldDescriptorProto.TYPE_STRING

    return file_proto


_POOL = descriptor_pool.Default()
try:
    _POOL.Add(_build_file_descriptor())
except TypeError:
    pass

Reading = message_factory.GetMessageClass(
    _POOL.FindMessageTypeByName("telemetry.Reading")
)
SensorRegistration = message_factory.GetMessageClass(
    _POOL.FindMessageTypeByName("telemetry.SensorRegistration")
)

__all__ = ["Reading", "SensorRegistration"]
