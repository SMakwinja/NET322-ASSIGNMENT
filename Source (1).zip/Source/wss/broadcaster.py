"""Tracks connected WebSocket clients and dispatches readings to them.

Owns the set of live clients, their subscription filters, and a way for
producers (the telemetry server) to publish a new reading.
"""
from __future__ import annotations

import asyncio
import json


class Broadcaster:
    """Fan-out of readings to the set of connected WebSocket clients."""

    def __init__(self) -> None:
        self._clients: dict[object, set[str] | None] = {}
        self._lock = asyncio.Lock()

    async def register(self, websocket) -> None:
        """Add a newly connected client."""
        async with self._lock:
            self._clients[websocket] = None

    async def unregister(self, websocket) -> None:
        """Remove a disconnected client."""
        async with self._lock:
            self._clients.pop(websocket, None)

    async def set_subscription(self, websocket, sensor_ids) -> None:
        """Replace the per-client sensor-id filter."""
        async with self._lock:
            if websocket in self._clients:
                self._clients[websocket] = set(sensor_ids) if sensor_ids else None

    async def publish(self, reading) -> None:
        """Push a reading to every interested client.

        Be careful with slow consumers — a blocked client must not stall
        delivery to the rest. Document the strategy you choose
        (drop, buffer-with-bound, disconnect, etc.) in the architecture
        document.
        """
        message = json.dumps(_reading_to_dict(reading))
        sensor_id = reading.get("sensor_id") if isinstance(reading, dict) else getattr(reading, "sensor_id", "")
        async with self._lock:
            targets = [
                websocket
                for websocket, subscription in self._clients.items()
                if subscription is None or sensor_id in subscription
            ]

        results = await asyncio.gather(
            *(_send_with_timeout(websocket, message) for websocket in targets),
            return_exceptions=True,
        )
        for websocket, result in zip(targets, results):
            if result is not None:
                await self.unregister(websocket)


async def _send_with_timeout(websocket, message: str):
    try:
        send = getattr(websocket, "send_str", None) or websocket.send
        await asyncio.wait_for(send(message), timeout=2.0)
    except Exception as exc:
        return exc
    return None


def _reading_to_dict(reading) -> dict:
    if isinstance(reading, dict):
        return reading
    return {
        "sensor_id": getattr(reading, "sensor_id"),
        "type": getattr(reading, "type"),
        "value": getattr(reading, "value"),
        "timestamp": getattr(reading, "timestamp"),
        "unit": getattr(reading, "unit", ""),
        "location": getattr(reading, "location", ""),
    }
