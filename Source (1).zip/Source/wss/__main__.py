"""Entry point for the WebSocket live-feed server.

Run with:
    python -m wss
"""
from __future__ import annotations

import asyncio

import websockets

from wss.handler import live


async def main() -> None:
    """Boot the WebSocket server.

    Responsibilities:
      - Construct the broadcaster.
      - Subscribe to the source of incoming readings (shared queue, DB poll,
        IPC channel — your design decision).
      - Start the WebSocket server on the configured host/port.
      - Run forever.
    """
    async with websockets.serve(live, "127.0.0.1", 8765):
        print("Standalone WebSocket endpoint listening on ws://127.0.0.1:8765/live")
        print("For live sensor data, prefer python -m server, which serves /live with shared storage.")
        await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
