"""WebSocket connection handler at /live.

One coroutine per connected client. Reads optional subscription messages
from the client and otherwise just forwards readings published by the
broadcaster.
"""
from __future__ import annotations

import json

from wss.broadcaster import Broadcaster

broadcaster = Broadcaster()


async def live(websocket, path: str | None = None) -> None:
    """Handle one WebSocket client connection.

    Protocol on this socket (JSON frames):
      Client -> Server (optional, after upgrade):
          {"action": "subscribe", "sensors": ["sensor-a", "sensor-b"]}
      Server -> Client (continuous):
          {"sensor_id": "...", "type": "...", "value": ..., "ts": ...}
    """
    path = path or getattr(websocket, "path", "/live")
    if path != "/live":
        await websocket.close(code=1008, reason="Use /live")
        return

    await broadcaster.register(websocket)
    try:
        async for message in websocket:
            try:
                data = json.loads(message)
            except json.JSONDecodeError:
                await websocket.send(json.dumps({"error": "Invalid JSON subscription message"}))
                continue
            if data.get("action") == "subscribe":
                sensors = data.get("sensors") or []
                await broadcaster.set_subscription(websocket, sensors)
                await websocket.send(json.dumps({"status": "subscribed", "sensors": sensors}))
    finally:
        await broadcaster.unregister(websocket)
