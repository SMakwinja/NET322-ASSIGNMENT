# IoT Telemetry Pipeline - Blantyre Greenhouse Prototype

Working asyncio prototype for remote greenhouse telemetry. Simulated sensors read
YAML configuration, send length-prefixed Protobuf readings over TCP, and the
central server exposes historical REST queries plus a JSON WebSocket live feed.

## Project Layout

```text
Source/
+-- proto/                  Protobuf schema and checked-in runtime module
+-- config/                 Sample YAML sensor configuration
+-- server/                 TCP ingest, REST API, WebSocket, dashboard
+-- wss/                    Reusable live-feed broadcaster helpers
+-- client/                 Sensor simulator
```

The main `server/` module runs TCP ingest, REST, WebSocket `/live`, and the
dashboard in one asyncio process. It uses in-memory storage for this prototype:
that keeps the demo low-cost, dependency-light, and naturally shared across TCP,
REST, and WebSocket handlers without blocking calls. The `Storage` interface is
small enough to replace with SQLite later when persistence across restarts is
needed.

## Setup

```bash
pip install -r requirements.txt
```

The repository includes `proto/telemetry_pb2.py`, so `protoc` is not required to
run the prototype.

## Running

In two separate terminals, from the `Source/` directory:

```bash
# 1. The telemetry server (TCP ingest + REST API + WebSocket + dashboard)
python -m server

# 2. The sensor simulator
python -m client --config config/sensors.yaml
```

Defaults:

- TCP Protobuf ingest: `127.0.0.1:9000`
- REST API and dashboard: `http://127.0.0.1:8080`
- WebSocket live feed: `ws://127.0.0.1:8080/live`

## REST API

Endpoints support server-driven content negotiation via the `Accept` header:
`application/json`, `application/xml`, `application/yaml`, and `text/yaml`.

| Method | Path                              | Purpose                              |
|--------|-----------------------------------|--------------------------------------|
| GET    | `/sensors`                        | List registered sensors              |
| GET    | `/sensors/{id}/readings`          | Historical readings with `?from=&to=` |
| POST   | `/sensors`                        | Register a new sensor                |
| DELETE | `/sensors/{id}`                   | Remove a sensor and its readings     |

Sessions are tracked via the `telemetry_session` cookie, set on the first REST
response and returned by the client on subsequent requests.

## WebSocket

Connect to `ws://<host>:<port>/live`. Send a JSON subscription message after
the upgrade to filter on specific sensor IDs:

```json
{"action": "subscribe", "sensors": ["bt-greenhouse-1-temp"]}
```

Frames on this channel are JSON for browser compatibility. Slow or disconnected
clients are removed after a short send timeout so one client cannot stall the
live feed for others.
