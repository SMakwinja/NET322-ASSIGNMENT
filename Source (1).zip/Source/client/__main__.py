"""Entry point for the sensor simulator.

Run with:
    python -m client --config config/sensors.yaml
"""
from __future__ import annotations

import asyncio
import argparse

import yaml

from client.simulator import SensorSimulator


async def main() -> None:
    """Load the YAML config, spawn one task per sensor, run them all."""
    parser = argparse.ArgumentParser(description="Run greenhouse sensor simulators")
    parser.add_argument("--config", default="config/sensors.yaml", help="YAML sensor config path")
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle) or {}

    server = config.get("server") or {}
    host = server.get("host", "127.0.0.1")
    port = int(server.get("port", 9000))
    sensors = config.get("sensors") or []
    if not sensors:
        raise SystemExit("No sensors configured")

    tasks = [
        asyncio.create_task(
            SensorSimulator(
                sensor_id=str(sensor["id"]),
                sensor_type=str(sensor["type"]),
                interval_seconds=float(sensor.get("interval_seconds", 5)),
                host=host,
                port=port,
                location=str(sensor.get("location", "")),
            ).run()
        )
        for sensor in sensors
    ]
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    asyncio.run(main())
