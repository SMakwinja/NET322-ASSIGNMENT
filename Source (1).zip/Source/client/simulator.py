"""Single-sensor simulation logic.

Each simulated sensor:
  - Connects to the telemetry server over TCP.
  - Generates plausible readings on its configured interval.
  - Encodes each reading as a Protobuf message and writes a length-prefixed
    frame on the socket.
  - Reconnects with backoff after transient network failures.
"""
from __future__ import annotations

import asyncio
import random
import struct
import time

from proto.telemetry_pb2 import Reading


class SensorSimulator:
    """Simulates one sensor pushing readings to the telemetry server."""

    def __init__(
        self,
        sensor_id: str,
        sensor_type: str,
        interval_seconds: float,
        host: str,
        port: int,
        location: str = "",
    ) -> None:
        self.sensor_id = sensor_id
        self.sensor_type = sensor_type
        self.interval_seconds = float(interval_seconds)
        self.host = host
        self.port = int(port)
        self.location = location
        base, spread, unit = _profile(sensor_type)
        self._value = random.uniform(base - spread, base + spread)
        self._base = base
        self._spread = spread
        self._unit = unit

    async def run(self) -> None:
        """Connect, then push readings on the configured interval forever."""
        backoff = 1.0
        while True:
            writer = None
            try:
                reader, writer = await asyncio.open_connection(self.host, self.port)
                print(f"{self.sensor_id}: connected to {self.host}:{self.port}")
                backoff = 1.0
                while True:
                    reading = self._generate_reading()
                    payload = reading.SerializeToString()
                    writer.write(struct.pack(">I", len(payload)) + payload)
                    await writer.drain()
                    await asyncio.sleep(self.interval_seconds)
            except (ConnectionError, OSError, asyncio.IncompleteReadError) as exc:
                print(f"{self.sensor_id}: connection lost ({exc}); retrying in {backoff:.1f}s")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30.0)
            finally:
                if writer is not None:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass

    def _generate_reading(self):
        """Produce a plausible next Reading for this sensor."""
        drift = (self._base - self._value) * 0.04
        noise = random.uniform(-self._spread, self._spread) * 0.18
        self._value = max(0.0, self._value + drift + noise)
        return Reading(
            sensor_id=self.sensor_id,
            type=self.sensor_type,
            value=round(self._value, 2),
            timestamp=time.time(),
            unit=self._unit,
            location=self.location,
        )


def _profile(sensor_type: str) -> tuple[float, float, str]:
    profiles = {
        "temperature": (26.0, 6.0, "C"),
        "humidity": (68.0, 18.0, "%"),
        "soil_moisture": (42.0, 14.0, "%"),
        "light": (620.0, 260.0, "lux"),
    }
    return profiles.get(sensor_type, (50.0, 10.0, ""))
