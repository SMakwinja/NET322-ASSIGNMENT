"""Storage layer for sensors and readings.

The backing store is an implementation detail (in-memory dict, SQLite,
something else). The interface below is what the rest of the server uses.
"""
from __future__ import annotations

import asyncio
from dataclasses import asdict, dataclass
from typing import Iterable, Optional


@dataclass(slots=True)
class Sensor:
    id: str
    type: str
    location: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class ReadingRecord:
    sensor_id: str
    type: str
    value: float
    timestamp: float
    unit: str = ""
    location: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class Storage:
    """Abstract storage interface."""

    async def add_sensor(self, sensor) -> None:
        """Register a new sensor."""
        raise NotImplementedError

    async def remove_sensor(self, sensor_id: str) -> None:
        """Remove a sensor and (optionally) its readings."""
        raise NotImplementedError

    async def list_sensors(self) -> Iterable:
        """Return all registered sensors."""
        raise NotImplementedError

    async def add_reading(self, reading) -> None:
        """Persist a single reading."""
        raise NotImplementedError

    async def get_readings(
        self,
        sensor_id: str,
        from_ts: Optional[float] = None,
        to_ts: Optional[float] = None,
    ) -> Iterable:
        """Return readings for a sensor within an optional time window."""
        raise NotImplementedError


class InMemoryStorage(Storage):
    """Small async-safe store for a prototype server process."""

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._sensors: dict[str, Sensor] = {}
        self._readings: list[ReadingRecord] = []

    async def add_sensor(self, sensor) -> None:
        sensor_obj = _coerce_sensor(sensor)
        async with self._lock:
            self._sensors[sensor_obj.id] = sensor_obj

    async def remove_sensor(self, sensor_id: str) -> None:
        async with self._lock:
            self._sensors.pop(sensor_id, None)
            self._readings = [
                reading for reading in self._readings if reading.sensor_id != sensor_id
            ]

    async def list_sensors(self) -> Iterable[Sensor]:
        async with self._lock:
            return list(self._sensors.values())

    async def add_reading(self, reading) -> None:
        record = _coerce_reading(reading)
        async with self._lock:
            self._readings.append(record)
            self._sensors.setdefault(
                record.sensor_id,
                Sensor(record.sensor_id, record.type, record.location),
            )

    async def get_readings(
        self,
        sensor_id: str,
        from_ts: Optional[float] = None,
        to_ts: Optional[float] = None,
    ) -> Iterable[ReadingRecord]:
        async with self._lock:
            return [
                reading
                for reading in self._readings
                if reading.sensor_id == sensor_id
                and (from_ts is None or reading.timestamp >= from_ts)
                and (to_ts is None or reading.timestamp <= to_ts)
            ]


def _coerce_sensor(sensor) -> Sensor:
    if isinstance(sensor, Sensor):
        return sensor
    if isinstance(sensor, dict):
        return Sensor(
            id=str(sensor["id"]),
            type=str(sensor["type"]),
            location=str(sensor.get("location", "")),
        )
    return Sensor(
        id=str(getattr(sensor, "id")),
        type=str(getattr(sensor, "type")),
        location=str(getattr(sensor, "location", "")),
    )


def _coerce_reading(reading) -> ReadingRecord:
    if isinstance(reading, ReadingRecord):
        return reading
    if isinstance(reading, dict):
        return ReadingRecord(
            sensor_id=str(reading["sensor_id"]),
            type=str(reading["type"]),
            value=float(reading["value"]),
            timestamp=float(reading["timestamp"]),
            unit=str(reading.get("unit", "")),
            location=str(reading.get("location", "")),
        )
    return ReadingRecord(
        sensor_id=str(getattr(reading, "sensor_id")),
        type=str(getattr(reading, "type")),
        value=float(getattr(reading, "value")),
        timestamp=float(getattr(reading, "timestamp")),
        unit=str(getattr(reading, "unit", "")),
        location=str(getattr(reading, "location", "")),
    )
