"""Content negotiation for the REST API.

Maps the `Accept` header on a request to a serializer for the response.
Supported media types:
    application/json
    application/xml
    application/yaml   (also accepts text/yaml)

Falls back to JSON when no supported type matches.
"""
from __future__ import annotations

import json
from xml.etree import ElementTree as ET

import yaml
from aiohttp import web

SUPPORTED = {
    "application/json": "application/json",
    "application/xml": "application/xml",
    "text/xml": "application/xml",
    "application/yaml": "application/yaml",
    "text/yaml": "application/yaml",
    "application/x-yaml": "application/yaml",
}


def negotiate(request: web.Request) -> str:
    """Return the chosen response media type for `request`."""
    accept = request.headers.get("Accept", "*/*")
    choices: list[tuple[float, int, str]] = []

    for order, part in enumerate(accept.split(",")):
        media_range, *params = [item.strip() for item in part.split(";")]
        q = 1.0
        for param in params:
            if param.startswith("q="):
                try:
                    q = float(param[2:])
                except ValueError:
                    q = 0.0
        if q <= 0:
            continue
        if media_range in ("*/*", "application/*"):
            choices.append((q, order, "application/json"))
        elif media_range in SUPPORTED:
            choices.append((q, order, SUPPORTED[media_range]))

    if not choices:
        return "application/json"
    choices.sort(key=lambda item: (-item[0], item[1]))
    return choices[0][2]


def serialize(payload, media_type: str) -> bytes:
    """Serialize `payload` (a dict or list of dicts) into bytes."""
    if media_type == "application/json":
        return json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")
    if media_type == "application/xml":
        return ET.tostring(_to_xml("response", payload), encoding="utf-8", xml_declaration=True)
    if media_type == "application/yaml":
        return yaml.safe_dump(payload, sort_keys=True).encode("utf-8")
    raise ValueError(f"Unsupported media type: {media_type}")


def _to_xml(name: str, value) -> ET.Element:
    element = ET.Element(_safe_tag(name))
    if isinstance(value, dict):
        for key, child in value.items():
            element.append(_to_xml(str(key), child))
    elif isinstance(value, list):
        for child in value:
            element.append(_to_xml("item", child))
    elif value is not None:
        element.text = str(value)
    return element


def _safe_tag(tag: str) -> str:
    return "".join(char if char.isalnum() or char in "_-" else "_" for char in tag)
