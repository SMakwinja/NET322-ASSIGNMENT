"""Entry point for the telemetry server.

Run with:
    python -m server
"""
from __future__ import annotations

import asyncio
import logging

from aiohttp import web

from server.rest_api import build_app
from server.storage import InMemoryStorage
from server.tcp_ingest import start_tcp_server
from wss.broadcaster import Broadcaster


async def main() -> None:
    """Boot the telemetry server.

    Responsibilities:
      - Initialise the storage layer.
      - Start the TCP ingest listener for sensor connections.
      - Start the aiohttp app hosting the REST API.
      - Wait until shutdown.
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    storage = InMemoryStorage()
    broadcaster = Broadcaster()
    tcp_server = await start_tcp_server("127.0.0.1", 9000, storage, broadcaster)

    app = build_app(storage, broadcaster)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 8080)
    await site.start()

    print("TCP ingest listening on 127.0.0.1:9000")
    print("REST API and dashboard listening on http://127.0.0.1:8080")
    try:
        async with tcp_server:
            await asyncio.Event().wait()
    finally:
        await runner.cleanup()


if __name__ == "__main__":
    asyncio.run(main())
