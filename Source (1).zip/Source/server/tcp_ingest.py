"""Asynchronous TCP listener for sensor connections.

Sensors connect over TCP and stream Protobuf-encoded readings. This module:
  - Accepts connections concurrently with asyncio.start_server.
  - Frames and decodes each Protobuf message from the byte stream.
  - Hands decoded readings to the storage layer (and optionally to a
    broadcaster so the WebSocket /live feed can push them).
  - Tolerates disconnects and malformed messages without crashing the server.

Framing convention: 4-byte big-endian length prefix followed by the Protobuf
payload of that length. Adjust if your design uses a different framing scheme.
"""
from __future__ import annotations

import asyncio
import logging
import struct

from google.protobuf.message import DecodeError

from proto.telemetry_pb2 import Reading

LOGGER = logging.getLogger(__name__)
MAX_FRAME_BYTES = 64 * 1024


async def handle_sensor(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    storage,
    broadcaster=None,
) -> None:
    """Handle one sensor connection until it closes."""
    peer = writer.get_extra_info("peername")
    try:
        while True:
            header = await reader.readexactly(4)
            (length,) = struct.unpack(">I", header)
            if length <= 0 or length > MAX_FRAME_BYTES:
                LOGGER.warning("Ignoring invalid frame length %s from %s", length, peer)
                break

            payload = await reader.readexactly(length)
            reading = Reading()
            try:
                reading.ParseFromString(payload)
            except DecodeError:
                LOGGER.warning("Malformed protobuf frame from %s", peer)
                continue

            await storage.add_reading(reading)
            if broadcaster is not None:
                await broadcaster.publish(reading)
    except asyncio.IncompleteReadError:
        pass
    finally:
        writer.close()
        await writer.wait_closed()


async def start_tcp_server(host: str, port: int, storage, broadcaster=None) -> asyncio.AbstractServer:
    """Start the TCP ingest server listening on (host, port)."""
    return await asyncio.start_server(
        lambda reader, writer: handle_sensor(reader, writer, storage, broadcaster),
        host,
        port,
    )
