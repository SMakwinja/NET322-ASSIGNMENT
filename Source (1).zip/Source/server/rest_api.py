"""REST API and WebSocket endpoint for the telemetry server."""
from __future__ import annotations

import json
import uuid

import yaml
from aiohttp import web
from aiohttp.web_ws import WebSocketResponse

from server.serialization import negotiate, serialize
from server.storage import InMemoryStorage, Sensor
from wss.broadcaster import Broadcaster


def _response(request: web.Request, payload, status: int = 200, headers=None) -> web.Response:
    media_type = negotiate(request)
    return web.Response(
        body=serialize(payload, media_type),
        status=status,
        content_type=media_type,
        headers=headers,
    )


async def list_sensors(request: web.Request) -> web.Response:
    """GET /sensors - list all registered sensors."""
    sensors = [sensor.to_dict() for sensor in await request.app["storage"].list_sensors()]
    return _response(request, {"sensors": sensors})


async def get_readings(request: web.Request) -> web.Response:
    """GET /sensors/{id}/readings - historical readings for a sensor."""
    try:
        from_ts = _parse_timestamp(request.query.get("from"))
        to_ts = _parse_timestamp(request.query.get("to"))
    except ValueError as exc:
        return _response(request, {"error": str(exc)}, status=400)

    sensor_id = request.match_info["id"]
    readings = [
        reading.to_dict()
        for reading in await request.app["storage"].get_readings(sensor_id, from_ts, to_ts)
    ]
    return _response(request, {"sensor_id": sensor_id, "readings": readings})


async def register_sensor(request: web.Request) -> web.Response:
    """POST /sensors - register a new sensor."""
    try:
        payload = await _read_payload(request)
        sensor = Sensor(
            id=str(payload["id"]),
            type=str(payload["type"]),
            location=str(payload.get("location", "")),
        )
    except (KeyError, TypeError, ValueError, json.JSONDecodeError, yaml.YAMLError) as exc:
        return _response(request, {"error": f"Invalid sensor payload: {exc}"}, status=400)

    await request.app["storage"].add_sensor(sensor)
    headers = {"Location": f"/sensors/{sensor.id}"}
    return _response(request, {"sensor": sensor.to_dict()}, status=201, headers=headers)


async def delete_sensor(request: web.Request) -> web.Response:
    """DELETE /sensors/{id} - remove a sensor."""
    sensor_id = request.match_info["id"]
    sensor_ids = {sensor.id for sensor in await request.app["storage"].list_sensors()}
    if sensor_id not in sensor_ids:
        return _response(request, {"error": "Sensor not found"}, status=404)
    await request.app["storage"].remove_sensor(sensor_id)
    return web.Response(status=204)


async def live_feed(request: web.Request) -> WebSocketResponse:
    """WebSocket /live endpoint using JSON frames."""
    websocket = WebSocketResponse(heartbeat=30)
    await websocket.prepare(request)

    broadcaster: Broadcaster = request.app["broadcaster"]
    await broadcaster.register(websocket)
    try:
        async for message in websocket:
            if message.type != web.WSMsgType.TEXT:
                continue
            try:
                data = json.loads(message.data)
            except json.JSONDecodeError:
                await websocket.send_json({"error": "Invalid JSON subscription message"})
                continue
            if data.get("action") == "subscribe":
                sensors = data.get("sensors") or []
                await broadcaster.set_subscription(websocket, sensors)
                await websocket.send_json({"status": "subscribed", "sensors": sensors})
    finally:
        await broadcaster.unregister(websocket)
    return websocket


async def dashboard(request: web.Request) -> web.Response:
    """Tiny browser dashboard for live greenhouse readings."""
    return web.Response(text=DASHBOARD_HTML, content_type="text/html")


@web.middleware
async def session_cookie_middleware(request: web.Request, handler):
    """Set/read the session cookie on every request."""
    session_id = request.cookies.get("telemetry_session")
    created = False
    if not session_id:
        session_id = uuid.uuid4().hex
        created = True
    request["session_id"] = session_id
    response = await handler(request)
    if created:
        response.set_cookie(
            "telemetry_session",
            session_id,
            httponly=True,
            samesite="Lax",
            max_age=60 * 60 * 24 * 30,
        )
    return response


def build_app(storage=None, broadcaster=None) -> web.Application:
    """Construct and return the aiohttp Application for REST and /live."""
    app = web.Application(middlewares=[session_cookie_middleware])
    app["storage"] = storage or InMemoryStorage()
    app["broadcaster"] = broadcaster or Broadcaster()
    app.router.add_get("/", dashboard)
    app.router.add_get("/live", live_feed)
    app.router.add_get("/sensors", list_sensors)
    app.router.add_get("/sensors/{id}/readings", get_readings)
    app.router.add_post("/sensors", register_sensor)
    app.router.add_delete("/sensors/{id}", delete_sensor)
    return app


async def _read_payload(request: web.Request) -> dict:
    content_type = request.content_type
    if content_type == "application/json":
        return await request.json()
    text = await request.text()
    if content_type in {"application/yaml", "text/yaml", "application/x-yaml"}:
        return yaml.safe_load(text) or {}
    if content_type in {"", "application/octet-stream"}:
        return json.loads(text)
    raise ValueError(f"Unsupported Content-Type: {content_type}")


def _parse_timestamp(value: str | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except ValueError as exc:
        raise ValueError(f"Invalid timestamp: {value}") from exc


DASHBOARD_HTML = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Blantyre Greenhouse Live Telemetry</title>
  <style>
    :root {
      color-scheme: light;
      --ink: #1b1f2f;
      --muted: #667085;
      --line: #dedaf2;
      --panel: #ffffff;
      --panel-soft: #fff7fb;
      --field: #f1edff;
      --green: #10b981;
      --teal: #06b6d4;
      --amber: #f59e0b;
      --berry: #ec4899;
      --violet: #7c3aed;
      --blue: #2563eb;
      --coral: #f97316;
      --charcoal: #1e1b4b;
      --shadow: 0 18px 45px rgba(55, 48, 163, .16);
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      min-height: 100vh;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background:
        linear-gradient(135deg, rgba(124, 58, 237, .12), transparent 32%),
        linear-gradient(225deg, rgba(6, 182, 212, .13), transparent 34%),
        linear-gradient(315deg, rgba(245, 158, 11, .12), transparent 38%),
        linear-gradient(90deg, rgba(30, 27, 75, .045) 1px, transparent 1px),
        linear-gradient(0deg, rgba(30, 27, 75, .045) 1px, transparent 1px),
        #fffaf4;
      background-size: 32px 32px;
      color: var(--ink);
    }

    .shell {
      width: min(1480px, 100%);
      margin: 0 auto;
      padding: 22px;
    }

    .topbar {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 18px;
      align-items: center;
      padding: 20px 22px;
      color: white;
      background:
        linear-gradient(135deg, #7c3aed 0%, #2563eb 36%, #06b6d4 68%, #10b981 100%),
        var(--charcoal);
      border: 1px solid rgba(255, 255, 255, .24);
      border-radius: 8px;
      box-shadow: var(--shadow);
      overflow: hidden;
      position: relative;
    }

    .topbar::after {
      content: "";
      position: absolute;
      inset: auto -12% -32px 42%;
      height: 80px;
      background:
        repeating-linear-gradient(90deg, rgba(255,255,255,.24) 0 2px, transparent 2px 18px);
      transform: rotate(-6deg);
      opacity: .45;
    }

    .brand {
      position: relative;
      z-index: 1;
      display: flex;
      gap: 14px;
      align-items: center;
      min-width: 0;
    }

    .brand-mark {
      width: 46px;
      height: 46px;
      flex: 0 0 46px;
      border: 1px solid rgba(255, 255, 255, .46);
      border-radius: 8px;
      display: grid;
      place-items: center;
      background: linear-gradient(135deg, rgba(255, 255, 255, .24), rgba(255, 255, 255, .08));
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, .2);
    }

    .brand-mark svg { width: 30px; height: 30px; }

    h1 {
      margin: 0;
      font-size: clamp(1.2rem, 2vw, 1.8rem);
      line-height: 1.05;
      letter-spacing: 0;
    }

    .subtitle {
      margin-top: 6px;
      color: rgba(255, 255, 255, .8);
      font-size: .9rem;
      line-height: 1.35;
    }

    .status-pill {
      position: relative;
      z-index: 1;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      min-height: 38px;
      padding: 0 14px;
      border: 1px solid rgba(255, 255, 255, .28);
      border-radius: 999px;
      background: linear-gradient(135deg, rgba(15, 23, 42, .2), rgba(255, 255, 255, .12));
      color: white;
      font-size: .88rem;
      white-space: nowrap;
    }

    .dot {
      width: 9px;
      height: 9px;
      border-radius: 999px;
      background: #facc15;
      box-shadow: 0 0 0 5px rgba(250, 204, 21, .22);
    }

    .dot.live {
      background: #86efac;
      box-shadow: 0 0 0 5px rgba(134, 239, 172, .22);
    }

    .metrics {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 12px;
      margin-top: 16px;
    }

    .metric {
      min-height: 108px;
      padding: 16px;
      border-radius: 8px;
      border: 1px solid var(--line);
      background:
        linear-gradient(135deg, var(--metric-tint, #f8f7ff), #ffffff 58%),
        var(--panel);
      box-shadow: 0 10px 24px rgba(55, 48, 163, .1);
      position: relative;
      overflow: hidden;
    }

    .metric::before {
      content: "";
      position: absolute;
      inset: 0 0 auto 0;
      height: 5px;
      background: var(--metric, var(--violet));
    }

    .metric:nth-child(1) { --metric: var(--violet); --metric-tint: #f3efff; }
    .metric:nth-child(2) { --metric: var(--coral); --metric-tint: #fff1e8; }
    .metric:nth-child(3) { --metric: var(--teal); --metric-tint: #e9fbff; }
    .metric:nth-child(4) { --metric: var(--berry); --metric-tint: #fff0f8; }

    .metric strong {
      color: var(--metric, var(--violet));
    }

    .metric label,
    .panel-title span,
    th {
      display: block;
      color: var(--muted);
      font-size: .72rem;
      font-weight: 800;
      letter-spacing: 0;
      text-transform: uppercase;
    }

    .metric strong {
      display: block;
      margin-top: 9px;
      font-size: clamp(1.55rem, 3vw, 2.35rem);
      line-height: 1;
    }

    .metric small {
      display: block;
      margin-top: 9px;
      color: var(--muted);
      font-size: .84rem;
    }

    .layout {
      display: grid;
      grid-template-columns: minmax(0, 1.45fr) minmax(340px, .9fr);
      gap: 16px;
      margin-top: 16px;
      align-items: start;
    }

    .panel {
      border-radius: 8px;
      border: 1px solid var(--line);
      background: rgba(255, 255, 255, .94);
      box-shadow: var(--shadow);
      overflow: hidden;
      position: relative;
    }

    .panel::before {
      content: "";
      display: block;
      height: 4px;
      background: linear-gradient(90deg, var(--violet), var(--blue), var(--teal), var(--green), var(--amber), var(--berry));
    }

    .panel-title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 14px;
      min-height: 58px;
      padding: 16px 18px;
      border-bottom: 1px solid var(--line);
      background:
        linear-gradient(135deg, rgba(124, 58, 237, .1), rgba(6, 182, 212, .09) 55%, rgba(245, 158, 11, .08)),
        linear-gradient(180deg, #ffffff, var(--panel-soft));
    }

    .panel-title h2 {
      margin: 3px 0 0;
      font-size: 1rem;
      letter-spacing: 0;
    }

    .sensor-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
      gap: 12px;
      padding: 14px;
    }

    .sensor-card {
      min-height: 168px;
      padding: 15px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background:
        linear-gradient(135deg, var(--card-tint, #f8f7ff), rgba(255,255,255,.95) 52%, #ffffff),
        var(--panel);
      position: relative;
      overflow: hidden;
      box-shadow: 0 10px 26px rgba(55, 48, 163, .09);
    }

    .sensor-card::before {
      content: "";
      position: absolute;
      inset: 0 auto 0 0;
      width: 5px;
      background: var(--accent, var(--green));
    }

    .sensor-card::after {
      content: "";
      position: absolute;
      inset: auto 12px 12px auto;
      width: 54px;
      height: 54px;
      border-radius: 8px;
      border: 1px solid var(--accent, var(--green));
      opacity: .12;
      transform: rotate(12deg);
    }

    .sensor-head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 10px;
    }

    .sensor-id {
      margin: 0;
      max-width: 170px;
      font-size: .95rem;
      overflow-wrap: anywhere;
    }

    .type-chip {
      flex: 0 0 auto;
      border-radius: 999px;
      padding: 5px 8px;
      background: var(--accent, var(--field));
      color: white;
      font-size: .72rem;
      font-weight: 800;
      text-transform: uppercase;
    }

    .reading {
      display: flex;
      align-items: baseline;
      gap: 8px;
      margin-top: 24px;
    }

    .reading strong {
      font-size: clamp(2rem, 4.4vw, 3.15rem);
      line-height: .9;
      letter-spacing: 0;
    }

    .reading span {
      color: var(--muted);
      font-size: .92rem;
      font-weight: 700;
    }

    .card-foot {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      margin-top: 22px;
      color: var(--muted);
      font-size: .82rem;
    }

    .spark {
      width: 100%;
      height: 34px;
      margin-top: 12px;
      display: block;
    }

    .stack {
      display: grid;
      gap: 16px;
    }

    .chart-wrap {
      padding: 14px 16px 18px;
    }

    #trend {
      display: block;
      width: 100%;
      height: 260px;
      border-radius: 8px;
      background:
        linear-gradient(135deg, #fff7ed, #f5f3ff 48%, #ecfeff);
      border: 1px solid var(--line);
    }

    .site-map {
      display: grid;
      grid-template-columns: .9fr 1.1fr;
      gap: 14px;
      padding: 16px;
      align-items: center;
    }

    .site-map svg {
      width: 100%;
      min-height: 210px;
      border-radius: 8px;
      border: 1px solid var(--line);
      background: linear-gradient(135deg, #fef3c7, #e0f2fe 52%, #fae8ff);
    }

    .health-list {
      display: grid;
      gap: 10px;
    }

    .health-row {
      display: grid;
      grid-template-columns: 88px minmax(0, 1fr);
      gap: 10px;
      align-items: center;
      font-size: .85rem;
    }

    .bar {
      height: 9px;
      border-radius: 999px;
      background: #ece8ff;
      overflow: hidden;
    }

    .bar span {
      display: block;
      height: 100%;
      width: var(--level, 0%);
      background: linear-gradient(90deg, var(--accent, var(--green)), #22d3ee);
    }

    .table-wrap {
      max-height: 312px;
      overflow: auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }

    th,
    td {
      padding: 12px 14px;
      border-bottom: 1px solid var(--line);
      text-align: left;
      vertical-align: middle;
    }

    td {
      font-size: .87rem;
      color: #28302b;
      overflow-wrap: anywhere;
    }

    .empty {
      min-height: 240px;
      display: grid;
      place-items: center;
      color: var(--muted);
      text-align: center;
      padding: 28px;
    }

    @media (max-width: 1000px) {
      .layout,
      .site-map {
        grid-template-columns: 1fr;
      }

      .metrics {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }

    @media (max-width: 640px) {
      .shell { padding: 12px; }
      .topbar { grid-template-columns: 1fr; }
      .metrics { grid-template-columns: 1fr; }
      .sensor-grid { grid-template-columns: 1fr; }
      #trend { height: 220px; }
    }
  </style>
</head>
<body>
  <div class="shell">
    <header class="topbar">
      <div class="brand">
        <div class="brand-mark" aria-hidden="true">
          <svg viewBox="0 0 40 40" role="img">
            <path d="M6 30V18L20 8l14 10v12" fill="none" stroke="white" stroke-width="2.5" stroke-linejoin="round"/>
            <path d="M11 30V18h18v12M15 30V18M25 30V18M11 24h18" fill="none" stroke="white" stroke-width="1.7" opacity=".78"/>
            <path d="M20 13c4 4 4 8 0 12-4-4-4-8 0-12Z" fill="#80e5b3"/>
          </svg>
        </div>
        <div>
          <h1>Blantyre Greenhouse Live Telemetry</h1>
          <div class="subtitle">Cooperative farm operations console</div>
        </div>
      </div>
      <div class="status-pill"><span id="statusDot" class="dot"></span><span id="connectionStatus">Connecting</span></div>
    </header>

    <section class="metrics" aria-label="Live telemetry summary">
      <div class="metric"><label>Active Sensors</label><strong id="activeSensors">0</strong><small id="locations">0 sites reporting</small></div>
      <div class="metric"><label>Average Temperature</label><strong id="avgTemp">--</strong><small>degrees Celsius</small></div>
      <div class="metric"><label>Average Humidity</label><strong id="avgHumidity">--</strong><small>relative humidity</small></div>
      <div class="metric"><label>Latest Reading</label><strong id="latestReading">--</strong><small id="latestSensor">awaiting sensor frame</small></div>
    </section>

    <main class="layout">
      <section class="panel">
        <div class="panel-title">
          <div><span>Sensor Array</span><h2>Current Conditions</h2></div>
          <span id="frameCount" class="type-chip">0 frames</span>
        </div>
        <div id="cards" class="sensor-grid">
          <div class="empty">Waiting for live greenhouse readings</div>
        </div>
      </section>

      <aside class="stack">
        <section class="panel">
          <div class="panel-title">
            <div><span>Signal Trend</span><h2>Last 60 Samples</h2></div>
          </div>
          <div class="chart-wrap"><canvas id="trend" width="780" height="420"></canvas></div>
        </section>

        <section class="panel">
          <div class="panel-title">
            <div><span>Farm Sites</span><h2>Coverage Map</h2></div>
          </div>
          <div class="site-map">
            <svg viewBox="0 0 360 260" aria-label="Greenhouse coverage map">
              <defs>
                <linearGradient id="roof" x1="0" x2="1">
                  <stop offset="0" stop-color="#7c3aed"/>
                  <stop offset=".45" stop-color="#06b6d4"/>
                  <stop offset="1" stop-color="#10b981"/>
                </linearGradient>
              </defs>
              <rect x="28" y="154" width="304" height="54" rx="8" fill="#fef3c7"/>
              <path d="M42 158L180 58l138 100" fill="none" stroke="url(#roof)" stroke-width="14" stroke-linejoin="round"/>
              <path d="M72 159L180 83l108 76" fill="none" stroke="#ffffff" stroke-width="4" opacity=".9"/>
              <g id="mapNodes">
                <circle cx="93" cy="178" r="12" fill="#f59e0b"/>
                <circle cx="180" cy="126" r="12" fill="#10b981"/>
                <circle cx="266" cy="178" r="12" fill="#ec4899"/>
              </g>
              <path d="M93 178L180 126L266 178" fill="none" stroke="#7c3aed" stroke-width="2" stroke-dasharray="6 6"/>
              <rect x="62" y="211" width="236" height="12" rx="6" fill="#bfdbfe"/>
            </svg>
            <div id="healthList" class="health-list"></div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-title">
            <div><span>Event Stream</span><h2>Recent Frames</h2></div>
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>Sensor</th><th>Value</th><th>Time</th></tr></thead>
              <tbody id="events"><tr><td colspan="3">No frames received</td></tr></tbody>
            </table>
          </div>
        </section>
      </aside>
    </main>
  </div>

  <script>
    const cards = document.getElementById("cards");
    const events = document.getElementById("events");
    const healthList = document.getElementById("healthList");
    const statusDot = document.getElementById("statusDot");
    const connectionStatus = document.getElementById("connectionStatus");
    const trend = document.getElementById("trend");
    const ctx = trend.getContext("2d");
    const readings = new Map();
    const histories = new Map();
    const eventRows = [];
    let frameCount = 0;

    const palette = {
      temperature: "#f97316",
      humidity: "#06b6d4",
      soil_moisture: "#10b981",
      light: "#ec4899"
    };

    const tints = {
      temperature: "#fff1e8",
      humidity: "#e9fbff",
      soil_moisture: "#edfff7",
      light: "#fff0f8"
    };

    const scheme = location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${scheme}://${location.host}/live`);

    ws.onopen = () => setConnection("Live", true);
    ws.onclose = () => setConnection("Offline", false);
    ws.onerror = () => setConnection("Link error", false);
    ws.onmessage = (event) => {
      const reading = JSON.parse(event.data);
      if (!reading.sensor_id) return;
      frameCount += 1;
      readings.set(reading.sensor_id, reading);
      const points = histories.get(reading.sensor_id) || [];
      points.push({ value: Number(reading.value), timestamp: Number(reading.timestamp), type: reading.type });
      histories.set(reading.sensor_id, points.slice(-60));
      eventRows.unshift(reading);
      if (eventRows.length > 8) eventRows.pop();
      render();
    };

    function setConnection(label, live) {
      connectionStatus.textContent = label;
      statusDot.classList.toggle("live", live);
    }

    function render() {
      const list = [...readings.values()].sort((a, b) => a.sensor_id.localeCompare(b.sensor_id));
      document.getElementById("activeSensors").textContent = list.length;
      document.getElementById("locations").textContent = `${new Set(list.map((r) => r.location || "Unknown")).size} sites reporting`;
      document.getElementById("frameCount").textContent = `${frameCount} frames`;

      const latest = eventRows[0];
      if (latest) {
        document.getElementById("latestReading").textContent = formatValue(latest);
        document.getElementById("latestSensor").textContent = latest.sensor_id;
      }

      document.getElementById("avgTemp").textContent = average(list, "temperature", "C");
      document.getElementById("avgHumidity").textContent = average(list, "humidity", "%");

      cards.innerHTML = list.length ? list.map(sensorCard).join("") : `<div class="empty">Waiting for live greenhouse readings</div>`;
      events.innerHTML = eventRows.length ? eventRows.map(eventRow).join("") : `<tr><td colspan="3">No frames received</td></tr>`;
      renderHealth(list);
      drawTrend();
    }

    function sensorCard(r) {
      const color = palette[r.type] || "#18815a";
      const tint = tints[r.type] || "#f3efff";
      return `
        <article class="sensor-card" style="--accent:${color};--card-tint:${tint}">
          <div class="sensor-head">
            <h3 class="sensor-id">${escapeHtml(r.sensor_id)}</h3>
            <span class="type-chip">${labelType(r.type)}</span>
          </div>
          <div class="reading"><strong>${Number(r.value).toFixed(1)}</strong><span>${r.unit || ""}</span></div>
          <canvas class="spark" width="320" height="48" data-sensor="${escapeHtml(r.sensor_id)}"></canvas>
          <div class="card-foot"><span>${escapeHtml(r.location || "Unknown")}</span><span>${timeLabel(r.timestamp)}</span></div>
        </article>
      `;
    }

    function eventRow(r) {
      return `<tr><td>${escapeHtml(r.sensor_id)}</td><td>${formatValue(r)}</td><td>${timeLabel(r.timestamp)}</td></tr>`;
    }

    function renderHealth(list) {
      const byType = ["temperature", "humidity", "soil_moisture", "light"];
      healthList.innerHTML = byType.map((type) => {
        const count = list.filter((r) => r.type === type).length;
        const level = Math.min(100, count * 35);
        return `<div class="health-row"><span>${labelType(type)}</span><div class="bar"><span style="--level:${level}%;--accent:${palette[type]}"></span></div></div>`;
      }).join("");
    }

    function drawTrend() {
      const width = trend.width;
      const height = trend.height;
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = "#fbfcfb";
      ctx.fillRect(0, 0, width, height);
      ctx.strokeStyle = "#dbe2dd";
      ctx.lineWidth = 1;
      for (let y = 50; y < height; y += 70) {
        ctx.beginPath();
        ctx.moveTo(28, y);
        ctx.lineTo(width - 20, y);
        ctx.stroke();
      }

      for (const [sensorId, points] of histories.entries()) {
        if (points.length < 2) continue;
        const color = palette[points[0].type] || "#18815a";
        const values = points.map((p) => p.value);
        const min = Math.min(...values);
        const max = Math.max(...values);
        const span = Math.max(1, max - min);
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        points.forEach((p, index) => {
          const x = 30 + (index / Math.max(1, points.length - 1)) * (width - 58);
          const y = height - 34 - ((p.value - min) / span) * (height - 72);
          if (index === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.stroke();
      }

      requestAnimationFrame(drawSparks);
    }

    function drawSparks() {
      document.querySelectorAll(".spark").forEach((canvas) => {
        const sensorId = canvas.dataset.sensor;
        const points = histories.get(sensorId) || [];
        const context = canvas.getContext("2d");
        context.clearRect(0, 0, canvas.width, canvas.height);
        if (points.length < 2) return;
        const values = points.map((p) => p.value);
        const min = Math.min(...values);
        const max = Math.max(...values);
        const span = Math.max(1, max - min);
        context.strokeStyle = palette[points[0].type] || "#18815a";
        context.lineWidth = 3;
        context.beginPath();
        points.forEach((p, index) => {
          const x = (index / Math.max(1, points.length - 1)) * canvas.width;
          const y = canvas.height - 4 - ((p.value - min) / span) * (canvas.height - 8);
          if (index === 0) context.moveTo(x, y);
          else context.lineTo(x, y);
        });
        context.stroke();
      });
    }

    function average(list, type, unit) {
      const selected = list.filter((r) => r.type === type).map((r) => Number(r.value));
      if (!selected.length) return "--";
      return `${(selected.reduce((sum, value) => sum + value, 0) / selected.length).toFixed(1)}${unit}`;
    }

    function formatValue(r) {
      return `${Number(r.value).toFixed(1)}${r.unit || ""}`;
    }

    function labelType(type) {
      return String(type || "sensor").replaceAll("_", " ");
    }

    function timeLabel(timestamp) {
      return new Date(Number(timestamp) * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    }

    function escapeHtml(value) {
      return String(value).replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      })[char]);
    }
  </script>
</body>
</html>"""
